<?php
/*
Template Name: Standard Page
*/
?>
<?php get_header(); ?>
<?php
get_template_part ('layout/modules/module', 'loop');
?>
<?php get_footer(); ?>
