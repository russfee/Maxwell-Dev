<!--Banner - Sub Page-->

<div class="row <?php the_field('sub_banner_width'); ?>">
	<div class="sub-banner-container" style="background-image: url(<?php the_field('sub_page_banner'); ?>)">
	</div> <!--sub-banner-container-->