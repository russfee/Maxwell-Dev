<?php if ( ! dynamic_sidebar( 'Sidebar' )) : ?>

<?php endif; ?>
